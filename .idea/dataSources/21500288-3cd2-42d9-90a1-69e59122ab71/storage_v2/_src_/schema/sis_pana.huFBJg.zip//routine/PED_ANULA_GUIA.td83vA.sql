CREATE PROCEDURE PED_ANULA_GUIA(IN X_COD_GUIA VARCHAR(12), IN x_usu VARCHAR(12))
  BEGIN















    DECLARE X_COD_ORDE      VARCHAR(12);



    declare EST varchar(1);















    select IND_ESTA



    into EST



    from fac_guia_remis where COD_GUIA= X_COD_GUIA;















    if EST = '0' then











      SELECT COD_ORDE



      into X_COD_ORDE



      FROM fac_guia_remis



      where COD_GUIA = X_COD_GUIA;















      UPDATE fac_guia_remis



      SET IND_ESTA='9',



        USU_MODI = x_usu,



        FEC_MODI = NOW()



      WHERE COD_GUIA= X_COD_GUIA;







      UPDATE fac_detal_guia_remis



      SET



        IMP_TOTA_PROD=0,



        IMP_PROD=0,



        UNI_SOLI=0,



        USU_MODI = x_usu,



        FEC_MODI = NOW()



      WHERE COD_GUIA=X_COD_GUIA;















      update fac_orden_compr



      set IND_ESTA ='0',



        usu_modi = x_usu,



        FEC_MODI= now()



      where COD_ORDE = X_COD_ORDE;







    END if;







  END;

