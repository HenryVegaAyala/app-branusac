CREATE PROCEDURE PED_MIGRA_FACTU_TO_GUIA(IN X_COD_FACTURA VARCHAR(12), IN x_usu VARCHAR(12))
  BEGIN

    DECLARE NUM_GUIA INT;
    DECLARE NUM_FACTU INT;
    DECLARE CGUIA INT;
    DECLARE DIR_PARTIDA VARCHAR(100);
    DECLARE CORDER INT;
    DECLARE igv DECIMAL(10, 2);
    DECLARE igvCalcu DECIMAL(10, 2);

    SELECT COD_FACT
    INTO NUM_GUIA
    FROM fac_factu
    WHERE COD_FACT = X_COD_FACTURA AND IND_ESTA <> '9';


    SELECT cast(VAL_PARA AS DECIMAL(10, 2))
    INTO igv
    FROM bas_param
    WHERE COD_PARA = '01';

    IF igv IS NULL
    THEN
      SET igv = 18;
    END IF;

    SET igvCalcu = (1 + igv / 100);
    SET autocommit = 0;


    SELECT VAL_PARA
    INTO DIR_PARTIDA
    FROM bas_param
    WHERE COD_PARA = '06';

    SELECT VAL_ACTU
    INTO NUM_GUIA
    FROM folio
    WHERE VAL_LLAVE = 1 FOR UPDATE;

    SELECT COD_FACT
    INTO NUM_FACTU
    FROM fac_factu
    WHERE COD_FACT = X_COD_FACTURA AND IND_ESTA <> '9';

    SELECT COD_GUIA
    INTO CGUIA
    FROM fac_factu
    where COD_FACT =	X_COD_FACTURA;

    IF NUM_FACTU IS NOT NULL AND CGUIA IS NULL
    THEN

      INSERT fac_guia_remis (
        COD_GUIA,         COD_ORDE,         COD_TIEN,         COD_CLIE,         FEC_EMIS,         DIR_PART,         FEC_TRAS,         IND_ESTA,         USU_DIGI,         FEC_DIGI        )

        SELECT
          NUM_GUIA,
          NULL,
          COD_TIEN,
          COD_CLIE,
          DATE(now()),
          DIR_PARTIDA,
          NULL,
          1,
          x_usu,
          DATE(NOW())
        FROM fac_factu
        WHERE COD_FACT = X_COD_FACTURA;

      INSERT fac_detal_guia_remis (
        COD_GUIA,         COD_PROD,         UNI_SOLI,         VAL_PROD,         IMP_PROD,         IGV_PROD,         IMP_TOTA_PROD,         USU_DIGI,         FEC_DIGI
      )

        SELECT
          NUM_GUIA,
          COD_PROD,
          UNI_SOLI,
          VAL_PROD,
          IMP_PROD,
          IGV_PROD,
          IMP_TOTA_PROD,
          x_usu,
          DATE(now())
        FROM fac_detal_factu
        WHERE COD_FACT = X_COD_FACTURA;

      UPDATE folio
      SET VAL_ACTU = (NUM_GUIA + 1)
      WHERE VAL_LLAVE = 1;

      UPDATE fac_factu
      SET IND_ESTA = '1',
        COD_GUIA   = NUM_GUIA
      WHERE COD_FACT = X_COD_FACTURA;

      COMMIT;

    END IF;

  END;

