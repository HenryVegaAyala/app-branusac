CREATE PROCEDURE AUDITORIA(IN X_USUARIO VARCHAR(100), IN X_VALOR INT)
  BEGIN

    CASE X_VALOR

      WHEN 01
      THEN
        UPDATE bas_param
        SET USU_MODI = X_USUARIO,
          FEC_MODI   = NOW();

      WHEN 02
      THEN
        UPDATE folio
        SET USUARIO = X_USUARIO,
          FECHA   = NOW()
        where VAL_LLAVE = 0;

      WHEN 03
      THEN
        UPDATE folio
        SET USUARIO = X_USUARIO,
          FECHA   = NOW()
        where VAL_LLAVE = 1;

      WHEN 04
      THEN
        UPDATE folio
        SET USUARIO = X_USUARIO,
          FECHA   = NOW()
        where VAL_LLAVE = 2;

    END CASE;
  END;

