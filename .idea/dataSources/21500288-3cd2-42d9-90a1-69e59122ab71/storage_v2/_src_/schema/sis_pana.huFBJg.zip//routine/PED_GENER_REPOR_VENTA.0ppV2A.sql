CREATE PROCEDURE PED_GENER_REPOR_VENTA(IN X_FEC_INI  VARCHAR(10), IN X_FEC_FIN VARCHAR(10), IN X_COD_CLIE VARCHAR(12),
                                       IN X_COD_TIEN VARCHAR(12), IN X_ESTADO VARCHAR(1), IN X_AGRUPA VARCHAR(1),
                                       IN x_usu      VARCHAR(20))
  BEGIN







    DECLARE pscodclie VARCHAR(12);



    DECLARE psdesclie VARCHAR(100);



    DECLARE pscodtien VARCHAR(12);



    DECLARE psdestien VARCHAR(100);



    DECLARE pscodprod VARCHAR(12);



    DECLARE psdesprod VARCHAR(100);







    DECLARE unidades int;



    DECLARE total DECIMAL(10,2);



    DECLARE v_finished INTEGER DEFAULT 0;







    DECLARE cliente_cursor CURSOR FOR



      SELECT COD_CLIE,



        (select des_clie from mae_clien z  where z.cod_clie= Y.cod_clie) des_clie,



        SUM(TOT_FACT) total



      from fac_factu Y



      WHERE (X_COD_CLIE IS NULL OR X_COD_CLIE='' OR COD_CLIE = X_COD_CLIE)



            AND FEC_FACT >= STR_TO_DATE(X_FEC_INI, '%d/%m/%Y')



            AND FEC_FACT <= STR_TO_DATE(X_FEC_FIN, '%d/%m/%Y')



            and (X_ESTADO is null or X_ESTADO='' or ind_esta = X_ESTADO)



      GROUP BY COD_CLIE,2;







    DECLARE tienda_cursor CURSOR FOR



      SELECT Y.COD_CLIE,



        (select des_clie from mae_clien z  where z.cod_clie= Y.cod_clie) des_clie,



        A.COD_tien,



        Des_TIEN,



        SUM(TOT_FACT) total



      FROM fac_factu Y, fac_guia_remis f, mae_tiend A



      WHERE Y.COD_GUIA= F.COD_GUIA



            AND F.COD_TIEN = A.COD_TIEN



            and (X_COD_CLIE IS NULL OR X_COD_CLIE='' OR Y.COD_CLIE = X_COD_CLIE)



            AND FEC_FACT >= STR_TO_DATE(X_FEC_INI, '%d/%m/%Y')



            AND FEC_FACT <= STR_TO_DATE(X_FEC_FIN, '%d/%m/%Y')



            and (X_ESTADO is null or X_ESTADO='' or Y.ind_esta = X_ESTADO)



      GROUP BY Y.COD_CLIE,2,3,4;











    DECLARE producto_cursor CURSOR FOR



      SELECT Y.COD_CLIE,



        (select des_clie from mae_clien z  where z.cod_clie= Y.cod_clie) des_clie,



        A.COD_TIEN,



        Des_TIEN,



        w.cod_prod,



        sap.des_larg,



        sum(w.uni_soli) unidades,



        SUM(w.imp_tota_prod) total



      FROM fac_detal_factu w,fac_factu Y, fac_guia_remis f, mae_tiend A, mae_produ sap



      WHERE w.cod_fact=y.cod_fact



            and Y.COD_GUIA= F.COD_GUIA



            AND F.COD_TIEN = A.COD_TIEN



            and w.cod_prod= sap.cod_prod



            and (X_COD_CLIE IS NULL OR X_COD_CLIE='' OR Y.COD_CLIE = X_COD_CLIE)



            AND FEC_FACT >= STR_TO_DATE(X_FEC_INI, '%d/%m/%Y')



            AND FEC_FACT <= STR_TO_DATE(X_FEC_FIN, '%d/%m/%Y')



            and (X_ESTADO is null or X_ESTADO='' or Y.ind_esta = X_ESTADO)



      GROUP BY Y.COD_CLIE,2,3,4,5,6;









    DECLARE CONTINUE HANDLER



    FOR NOT FOUND SET v_finished = 1;











    DELETE FROM tmp_repor_venta WHERE USU_DIGI = x_usu;







    IF X_AGRUPA = '0' THEN









      OPEN cliente_cursor;









      loop1: LOOP









        FETCH cliente_cursor INTO pscodclie, psdesclie,total;











        IF v_finished = 1 THEN



          LEAVE loop1;



        END IF;







        insert into tmp_repor_venta(COD_CLIE,DES_CLIE,IMP_TOTA,USU_DIGI) values(pscodclie,psdesclie,total,x_usu);







      END LOOP loop1;









      CLOSE cliente_cursor;







    END IF;















    IF X_AGRUPA = '1' THEN









      OPEN tienda_cursor;









      loop1: LOOP









        FETCH tienda_cursor INTO pscodclie,psdesclie,pscodtien,psdestien,total;











        IF v_finished = 1 THEN



          LEAVE loop1;



        END IF;







        insert into tmp_repor_venta(COD_CLIE,DES_CLIE,COD_TIEN,DIR_TIEN,IMP_TOTA,USU_DIGI)



        values(pscodclie,psdesclie,pscodtien,psdestien,total,x_usu);











      END LOOP loop1;









      CLOSE tienda_cursor;







    END IF;











    IF X_AGRUPA = '2' THEN









      OPEN producto_cursor;









      loop1: LOOP









        FETCH producto_cursor INTO pscodclie,psdesclie,pscodtien,psdestien,pscodprod,psdesprod,unidades,total;











        IF v_finished = 1 THEN



          LEAVE loop1;



        END IF;







        insert into tmp_repor_venta(COD_CLIE,DES_CLIE,COD_TIEN,DIR_TIEN,COD_PROD,DES_LARG,UNI_SOLI,IMP_TOTA,USU_DIGI)



        values(pscodclie,psdesclie,pscodtien,psdestien,pscodprod,psdesprod,unidades,total,x_usu);







      END LOOP loop1;









      CLOSE producto_cursor;







    END IF;







  END;

