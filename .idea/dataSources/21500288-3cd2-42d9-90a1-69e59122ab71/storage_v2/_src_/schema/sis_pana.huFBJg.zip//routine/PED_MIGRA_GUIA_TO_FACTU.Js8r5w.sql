CREATE PROCEDURE PED_MIGRA_GUIA_TO_FACTU(IN X_COD_GUIA VARCHAR(12), IN x_usu VARCHAR(12))
  BEGIN

    DECLARE NUM_FACTU INT;
    DECLARE CORDER INT;
    DECLARE CGUIA INT;
    DECLARE DIR_PARTIDA VARCHAR(100);
    DECLARE igv DECIMAL(10, 2);
    DECLARE igvCalcu DECIMAL(10, 2);

    SELECT COD_FACT
    INTO NUM_FACTU
    FROM fac_factu
    WHERE COD_GUIA = X_COD_GUIA AND IND_ESTA <> '9';

    SELECT
      COD_GUIA,
      COD_ORDE
    INTO CGUIA, CORDER
    FROM fac_guia_remis
    WHERE COD_GUIA = X_COD_GUIA;


    IF NUM_FACTU IS NULL AND CGUIA IS NOT NULL
    THEN
      SELECT cast(VAL_PARA AS DECIMAL(10, 2))
      INTO igv
      FROM bas_param
      WHERE COD_PARA = '01';
      IF igv IS NULL
      THEN
        SET igv = 18;
      END IF;

      SET igvCalcu = (1 + igv / 100);
      SET autocommit = 0;

            
            SELECT VAL_ACTU
      INTO NUM_FACTU
      FROM folio
      WHERE VAL_LLAVE = 2 FOR UPDATE;


      INSERT fac_factu (
        COD_FACT,
        COD_CLIE,
        COD_GUIA,
        FEC_FACT,
        IND_ESTA,
        VAL_IGV,
        TOT_UNID_FACT,
        TOT_FACT_SIN_IGV,
        TOT_IGV,
        TOT_FACT,
        USU_DIGI,
        FEC_DIGI,
        COD_TIEN)

        SELECT
          NUM_FACTU,
          COD_CLIE,
          COD_GUIA,
          DATE(NOW()),
          '1',
          igv,
          (SELECT TOT_UNID_SOLI
           FROM fac_orden_compr
           WHERE COD_ORDE = CORDER) TOT_UNID_FACT,

          (SELECT TOT_MONT_ORDE
           FROM fac_orden_compr
           WHERE COD_ORDE = CORDER) TOT_MONT_ORDE,

          (SELECT TOT_MONT_IGV
           FROM fac_orden_compr
           WHERE COD_ORDE = CORDER) TOT_MONT_IGV,

          (SELECT TOT_FACT
           FROM fac_orden_compr
           WHERE COD_ORDE = CORDER) TOT_FACT,

          x_usu,
          now(),
          COD_CLIE

        FROM fac_guia_remis
        WHERE COD_GUIA = X_COD_GUIA;


      INSERT fac_detal_factu (
        COD_FACT,
        COD_PROD,
        UNI_SOLI,
        VAL_PROD,
        IMP_PROD,
        IGV_PROD,
        IMP_TOTA_PROD,
        USU_DIGI,
        FEC_DIGI,
        COD_CLIE,
        COD_TIEN
      )

        SELECT
          NUM_FACTU,
          COD_PROD,
          UNI_SOLI,
          VAL_PROD,
          IMP_PROD,
          IGV_PROD,
          IMP_TOTA_PROD,
          x_usu,
          now(),
          (SELECT COD_CLIE
           FROM fac_factu
           WHERE COD_FACT = NUM_FACTU) COD_CLIE,
          (SELECT COD_TIEN
           FROM fac_factu
           WHERE COD_FACT = NUM_FACTU) COD_TIEN
        FROM fac_detal_guia_remis Y
        WHERE COD_GUIA = X_COD_GUIA;

                  
            UPDATE folio
      SET VAL_ACTU = NUM_FACTU + 1
      WHERE VAL_LLAVE = 2;

      UPDATE fac_guia_remis
      SET IND_ESTA = '1',
        usu_modi   = x_usu,
        fec_modi   = now()
      WHERE COD_GUIA = X_COD_GUIA;

      UPDATE fac_orden_compr
      SET IND_ESTA = '2',
        usu_modi   = x_usu,
        fec_modi   = now()
      WHERE COD_ORDE = CORDER;

      COMMIT;

      SET autocommit = 1;

    END IF;


  END;

