CREATE PROCEDURE PED_CREAR_DETAL_FACT(IN fila        INT, IN x_cod_fact VARCHAR(12), IN x_cod_tiend VARCHAR(6),
                                      IN x_cod_clien VARCHAR(6), IN x_COD_PROD VARCHAR(12), IN x_NRO_UNID INT(12),
                                      IN x_VAL_PREC  DECIMAL(10, 2), IN x_VAL_MONT_UNID DECIMAL(10, 2),
                                      IN x_DES_LARG  VARCHAR(60), IN x_VAL_USU VARCHAR(10), IN x_VAL_PCIP VARCHAR(60))
  BEGIN

    DECLARE igv DECIMAL(10, 2);
    DECLARE igvCalcu DECIMAL(10, 2);

    SELECT cast(VAL_PARA AS DECIMAL(10, 2))
    INTO igv
    FROM bas_param
    WHERE COD_PARA = '01';


    IF igv IS NULL
    THEN
      SET igv = 18;
    END IF;


    SET igvCalcu = (1 + igv / 100);


    UPDATE fac_detal_factu
    SET FEC_DIGI = now()
    WHERE COD_FACT = x_cod_fact;


    IF NOT EXISTS(
        SELECT VAL_PROD
        FROM mae_produ_tiend AS C
        WHERE cod_tien = x_cod_tiend AND COD_CLIE = x_cod_clien AND COD_PROD = x_COD_PROD
    )

    THEN

      INSERT INTO mae_produ_tiend (COD_TIEN, COD_CLIE, COD_PROD, IND_TIPO, VAL_PROD, VAL_DESC, VAL_PROD_DESC, USU_DIGI, FEC_DIGI)
      VALUES (x_cod_tiend, x_cod_clien, x_COD_PROD, '0', x_VAL_PREC, 0, x_VAL_PREC, x_VAL_USU, NOW());

    ELSE

      UPDATE mae_produ_tiend
      SET VAL_PROD    = x_VAL_PREC,
        VAL_PROD_DESC = x_VAL_PREC,
        fec_modi      = now(),
        USU_MODI      = x_VAL_USU
      WHERE cod_tien = x_cod_tiend AND COD_CLIE = x_cod_clien AND COD_PROD = x_COD_PROD;

    END IF;

    IF fila = 0
    THEN
      DELETE FROM fac_detal_factu
      WHERE COD_FACT = x_cod_fact AND cod_tien = x_cod_tiend AND COD_CLIE = x_cod_clien;

      UPDATE folio
      SET VAL_ACTU = (VAL_ACTU + 1)
      WHERE VAL_LLAVE = 2;

    END IF;

    INSERT INTO fac_detal_factu (
      COD_CLIE,
      COD_TIEN,
      COD_FACT,
      COD_PROD,
      UNI_SOLI,
      VAL_PROD,
      IMP_PROD,
      IMP_TOTA_PROD,
      IGV_PROD,
      USU_DIGI,
      FEC_DIGI)

    VALUES (
      x_cod_clien,
      x_cod_tiend,
      x_cod_fact,
      x_COD_PROD,
      x_NRO_UNID,
      x_VAL_PREC,
      x_VAL_MONT_UNID,
      x_VAL_MONT_UNID * igvCalcu,
      x_VAL_MONT_UNID * (igv/100),
      x_VAL_USU,
      NOW());

    UPDATE fac_factu
    SET FEC_FACT = now(),
      VAL_IGV    = igv,
      FEC_DIGI   = now()
    WHERE COD_FACT = x_cod_fact;

  END;

