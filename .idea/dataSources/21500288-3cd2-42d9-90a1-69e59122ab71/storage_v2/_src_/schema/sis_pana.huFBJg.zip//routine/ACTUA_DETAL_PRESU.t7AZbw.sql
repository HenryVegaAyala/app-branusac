CREATE PROCEDURE ACTUA_DETAL_PRESU(IN fila        INT, IN x_cod_presu INT(99), IN x_cod_presu_det INT(99),
                                   IN x_cod_clien INT(99), IN x_NRO_UNID INT, IN x_DES_LARG VARCHAR(250),
                                   IN x_VAL_PREC  DECIMAL(10, 2), IN x_VAL_MONT_UNID DECIMAL(10, 2))
  BEGIN

    IF fila = 0  THEN

      delete FROM detalle_presupuesto
      WHERE COD_PRESU = x_cod_presu;

    END IF;

    INSERT INTO  detalle_presupuesto (
      COD_PRESU,
      COD_PRESU_DET,
      COD_PRODUC,
      CANTIDAD,
      DESCRIPCION,
      TOTAL,
      COD_CLIE,
      PRECIO
    )

    VALUES (
      x_cod_presu,
      x_cod_presu_det,
      1,
      x_NRO_UNID,
      x_DES_LARG,
      x_VAL_MONT_UNID,
      x_cod_clien,
      x_VAL_PREC
    );

  END;

