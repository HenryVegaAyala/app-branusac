CREATE PROCEDURE PED_MIGRA_OC_TO_GUIA(IN X_COD_ORDE VARCHAR(12), IN x_usu VARCHAR(12), OUT ind_detalle_oc INT)
  proc_label:BEGIN







    DECLARE NUM_GUIA INT;



    DECLARE CORDEN INT;



    DECLARE DIR_PARTIDA VARCHAR(100);

    declare detalleoc INT;





    declare igv decimal(10,2);



    declare igvCalcu decimal(10,2);







    select count(1) into detalleoc

    from fac_detal_orden_compr

    where cod_orde = X_COD_ORDE;

    set ind_detalle_oc=1;

    if detalleoc = 0 then

      set ind_detalle_oc=0;

      LEAVE proc_label;

    end if;









    select COD_GUIA into NUM_GUIA



    from fac_guia_remis



    where COD_ORDE = X_COD_ORDE and IND_ESTA <> '9';







    select COD_ORDE into CORDEN



    FROM fac_orden_compr



    WHERE COD_ORDE=X_COD_ORDE;







    if NUM_GUIA is null  AND CORDEN IS NOT NULL then







      SELECT cast(VAL_PARA as decimal(10,2)) INTO igv



      FROM bas_param



      WHERE COD_PARA='01';







      SELECT VAL_PARA INTO DIR_PARTIDA



      FROM bas_param



      WHERE COD_PARA='O2';







      IF igv is null THEN



        SET igv=18 ;



      END IF;



      set igvCalcu = (1+ igv/100);



      set autocommit =0 ;

            
            SELECT VAL_ACTU into num_guia from folio WHERE VAL_LLAVE = 1 FOR UPDATE ;





      INSERT fac_guia_remis (

        COD_GUIA ,

        COD_ORDE ,

        COD_TIEN ,

        COD_CLIE ,

        FEC_EMIS ,

        DIR_PART ,

        FEC_TRAS ,

        IND_ESTA ,

        USU_DIGI ,

        FEC_DIGI )

        SELECT NUM_GUIA,

          X_COD_ORDE,

          COD_TIEN,

          COD_CLIE,

          DATE(NOW()),

          DIR_PARTIDA,

          FEC_ENVI,

          '0',

          x_usu,

          now()

        FROM fac_orden_compr

        WHERE COD_ORDE=X_COD_ORDE;











      INSERT fac_detal_guia_remis (

        COD_GUIA,

        COD_PROD,

        PES_PROD,

        UNI_SOLI,

        VAL_PROD,

        IMP_PROD,

        IGV_PROD,

        IMP_TOTA_PROD ,

        USU_DIGI ,

        FEC_DIGI )

        SELECT NUM_GUIA,

          COD_PROD,

          (select VAL_PESO from mae_produ X WHERE X.COD_PROD = Y.COD_PROD) VAL_PESO,

          NRO_UNID,

          VAL_PREC,

          VAL_MONT_UNID,

          VAL_MONT_IGV,

          VAL_MONT_UNID + VAL_MONT_IGV,

          x_usu,

          now()

        FROM fac_detal_orden_compr Y

        WHERE COD_ORDE=X_COD_ORDE;




                  
            UPDATE folio
      SET VAL_ACTU = NUM_GUIA + 1
      where VAL_LLAVE = 1;












      update fac_orden_compr



      set IND_ESTA ='1',



        usu_modi = x_usu,



        fec_modi= now()



      where COD_ORDE=X_COD_ORDE;



      commit;

      set autocommit =1 ;

    end if;



  END;

