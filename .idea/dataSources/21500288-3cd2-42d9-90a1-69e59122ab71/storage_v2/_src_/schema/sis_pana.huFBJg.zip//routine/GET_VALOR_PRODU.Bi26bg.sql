CREATE FUNCTION GET_VALOR_PRODU(x_COD_PRODU VARCHAR(12), x_COD_TIEN VARCHAR(6), x_COD_CLIE VARCHAR(6))
  RETURNS DECIMAL(12, 2)
  BEGIN







    declare precio decimal(10,2);







    set precio=0;























    SELECT val_prod into precio







    FROM mae_produ_tiend







    where cod_prod= x_COD_PRODU







          and cod_tien = x_COD_TIEN







          AND COD_CLIE= x_COD_CLIE;















    if precio is null or precio=0 then















      SELECT val_prod into precio







      FROM mae_produ







      where cod_prod= x_COD_PRODU;















    end if;























    RETURN precio;







  END;

