CREATE PROCEDURE PED_ANULA_FACTU(IN X_COD_FACTU VARCHAR(12), IN x_usu VARCHAR(12))
  BEGIN











    DECLARE CORDE      VARCHAR(12);



    DECLARE CGUIA      VARCHAR(12);







    SELECT COD_GUIA into CGUIA



    FROM FAC_FACTU



    where COD_FACT = X_COD_FACTU;







    SELECT COD_ORDE into CORDE



    FROM FAC_GUIA_REMIS



    where COD_GUIA = CGUIA;



















    UPDATE fac_factu



    SET IND_ESTA='9',



      TOT_UNID_FACT=0,



      TOT_FACT_SIN_IGV=0,



      TOT_IGV=0,



      TOT_FACT=0,



      USU_MODI = x_usu,



      FEC_MODI = NOW()



    WHERE COD_FACT= X_COD_FACTU;











    UPDATE fac_detal_factu



    SET IMP_PROD=0,



      IMP_TOTA_PROD=0,



      IGV_PROD=0,



      VAL_PROD=0,



      UNI_SOLI=0,



      USU_MODI = x_usu,



      FEC_MODI = NOW()



    WHERE COD_FACT= X_COD_FACTU;







    UPDATE fac_guia_remis



    SET IND_ESTA='0',



      USU_MODI = x_usu,



      FEC_MODI = NOW()



    WHERE COD_GUIA= CGUIA;



















    update fac_orden_compr



    set IND_ESTA ='1',



      usu_modi = x_usu,



      FEC_MODI= now()



    where COD_ORDE = CORDE;







  END;

