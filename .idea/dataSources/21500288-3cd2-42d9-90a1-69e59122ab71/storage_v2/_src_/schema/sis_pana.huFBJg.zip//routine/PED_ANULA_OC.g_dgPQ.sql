CREATE PROCEDURE PED_ANULA_OC(IN X_COD_ORDEN VARCHAR(12), IN x_usu VARCHAR(12))
  BEGIN















    declare EST varchar(1);







    select IND_ESTA into EST



    from fac_orden_compr where COD_ORDE=X_COD_ORDEN;











    if EST = '0' then



















      update fac_orden_compr



      set IND_ESTA ='9',



        usu_modi = x_usu,



        fec_modi= now(),



        TOT_UNID_SOLI=0,



        TOT_MONT_ORDE=0,



        TOT_MONT_IGV=0,



        TOT_FACT=0



      where COD_ORDE=X_COD_ORDEN;







      UPDATE fac_detal_orden_compr



      SET NRO_UNID=0,



        VAL_MONT_UNID=0,



        VAL_MONT_IGV=0,



        USU_MODI = x_usu,



        FEC_MODI = NOW()



      WHERE COD_ORDE= X_COD_ORDEN;







    END if;







  END;

